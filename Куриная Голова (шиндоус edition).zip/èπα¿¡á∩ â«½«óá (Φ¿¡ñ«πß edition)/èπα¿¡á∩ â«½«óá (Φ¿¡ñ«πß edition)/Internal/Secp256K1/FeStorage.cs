﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.FeStorage
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using System;

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal class FeStorage
  {
    public uint[] N;

    public FeStorage()
    {
      this.N = new uint[8];
    }

    public FeStorage(uint[] arr)
    {
      this.N = arr;
    }

    public FeStorage(FeStorage other)
    {
      this.N = new uint[other.N.Length];
      Array.Copy((Array) other.N, (Array) this.N, other.N.Length);
    }

    public FeStorage Clone()
    {
      return new FeStorage(this);
    }
  }
}
