﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.ContextStruct
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using System;

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal class ContextStruct
  {
    public EcMultContext EcMultCtx;
    public EcmultGenContext EcMultGenCtx;
    public EventHandler<Callback> IllegalCallback;
    public EventHandler<Callback> ErrorCallback;

    public ContextStruct()
    {
      this.EcMultCtx = new EcMultContext();
      this.EcMultGenCtx = new EcmultGenContext();
    }
  }
}
