﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.NonceFunction
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal delegate bool NonceFunction(byte[] nonce32, byte[] msg32, byte[] key32, byte[] algo16, byte[] data, uint attempt);
}
