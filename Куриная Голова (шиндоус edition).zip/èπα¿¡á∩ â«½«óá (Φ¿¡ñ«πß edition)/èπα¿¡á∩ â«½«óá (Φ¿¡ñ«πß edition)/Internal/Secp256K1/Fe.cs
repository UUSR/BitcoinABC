﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.Fe
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using System;

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal class Fe
  {
    public uint[] N;

    public uint this[int index]
    {
      get
      {
        return this.N[index];
      }
    }

    public Fe()
    {
      this.N = new uint[10];
    }

    public Fe(uint[] arr)
    {
      this.N = arr;
    }

    public Fe(Fe other)
    {
      this.N = new uint[other.N.Length];
      Array.Copy((Array) other.N, (Array) this.N, other.N.Length);
    }

    public Fe Clone()
    {
      return new Fe(this);
    }
  }
}
