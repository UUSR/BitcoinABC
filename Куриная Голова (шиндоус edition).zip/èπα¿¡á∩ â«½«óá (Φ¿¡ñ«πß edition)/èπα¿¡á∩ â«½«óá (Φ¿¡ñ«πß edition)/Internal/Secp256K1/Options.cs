﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.Options
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using System;

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  [Flags]
  internal enum Options : uint
  {
    FlagsTypeMask = 255, // 0x000000FF
    FlagsTypeContext = 1,
    FlagsTypeCompression = 2,
    FlagsBitContextVerify = 256, // 0x00000100
    FlagsBitContextSign = 512, // 0x00000200
    FlagsBitCompression = FlagsBitContextVerify, // 0x00000100
    ContextVerify = FlagsBitCompression | FlagsTypeContext, // 0x00000101
    ContextSign = FlagsBitContextSign | FlagsTypeContext, // 0x00000201
    ContextNone = FlagsTypeContext, // 0x00000001
    EcCompressed = FlagsBitCompression | FlagsTypeCompression, // 0x00000102
    EcUncompressed = FlagsTypeCompression, // 0x00000002
  }
}
