﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Sha256.Sha256T
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

namespace Cryptography.ECDSA.Internal.Sha256
{
  internal class Sha256T
  {
    public uint[] S;
    public uint[] Buf;
    public uint Bytes;

    public Sha256T()
    {
      this.S = new uint[8];
      this.Buf = new uint[16];
      this.Bytes = 0U;
    }
  }
}
