﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Sha256.HmacSha256T
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

namespace Cryptography.ECDSA.Internal.Sha256
{
  internal class HmacSha256T
  {
    public Sha256T Inner;
    public Sha256T Outer;

    public HmacSha256T()
    {
      this.Inner = new Sha256T();
      this.Outer = new Sha256T();
    }
  }
}
