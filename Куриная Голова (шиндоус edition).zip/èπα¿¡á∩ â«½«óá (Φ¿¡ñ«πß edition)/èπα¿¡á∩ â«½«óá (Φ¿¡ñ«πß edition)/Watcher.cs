﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Куриная_Голова__шиндоус_edition_
{
    public partial class Watcher : Form
    {
        public Watcher()
        {
            InitializeComponent();
        }
    }
}
