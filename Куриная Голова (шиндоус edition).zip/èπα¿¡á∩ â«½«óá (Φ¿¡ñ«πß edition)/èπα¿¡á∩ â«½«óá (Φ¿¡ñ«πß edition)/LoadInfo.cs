﻿using System;
using System.Net;
using System.Text;

namespace Куриная_Голова__шиндоус_edition_
{
    internal static class LoadInfo
    {
        private static readonly WebClient LoadWc = new WebClient();
        private static readonly int _timeout = 10;

        internal static double GetBalance(string pubkey)
        {
            var address = "https://blockchain.info/q/addressbalance/" + pubkey;
            var num = 0;
            label_1:
            try
            {
                num++;
                var bytes = LoadInfo.LoadWc.DownloadData(address);
                var result = 0.0;
                double.TryParse(Encoding.UTF8.GetString(bytes), out result);
                return result / 100000000.0;
            }
            catch
            {
                if (num >= _timeout)
                {
                    return -1.0;
                }
                goto label_1;
            }
        }

        internal static double GetSent(string pubkey)
        {
            var address = "https://blockchain.info/q/getsentbyaddress/" + pubkey;
            var num = 0;
            label_1:
            try
            {
                num++;
                var bytes = LoadInfo.LoadWc.DownloadData(address);
                var result = 0.0;
                double.TryParse(Encoding.UTF8.GetString(bytes), out result);
                return result / 100000000.0;
            }
            catch
            {
                if (num >= _timeout)
                {
                    return -1.0;
                }
                goto label_1;
            }
        }

        internal static double GetReceived(string pubkey)
        {
            var address = "https://blockchain.info/q/getreceivedbyaddress/"+pubkey;
            var num = 0;
            label_1:
            try
            {
                num++;
                var bytes = LoadInfo.LoadWc.DownloadData(address);
                var result = 0.0;
                double.TryParse(Encoding.UTF8.GetString(bytes), out result);
                return result / 100000000.0;
            }
            catch
            {
                if (num >= _timeout)
                {
                    return -1.0;
                }
                goto label_1;
            }
        }

        internal static string GetFirstSeen(string pubkey)
        {
            var address = "https://blockchain.info/q/addressfirstseen/" + pubkey;
            var num = 0;
            label_1:
            try
            {
                num++;
                var bytes = LoadInfo.LoadWc.DownloadData(address);
                var result = 0;
                int.TryParse(Encoding.UTF8.GetString(bytes), out result);
                return Epoch2String(result);
            }
            catch
            {
                if (num >= _timeout)
                {
                    return Epoch2String(-1);
                }
                goto label_1;
            }
        }

        internal static int GetFirstSeenInt(string pubkey)
        {
            var address = "https://blockchain.info/q/addressfirstseen/" + pubkey;
            var num = 0;
            label_1:
            try
            {
                num++;
                var bytes = LoadInfo.LoadWc.DownloadData(address);
                var result = 0;
                int.TryParse(Encoding.UTF8.GetString(bytes), out result);
                return result;
            }
            catch
            {
                if (num >= _timeout)
                {
                    return -1;
                }
                goto label_1;
            }
        }

        private static string Epoch2String(int epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(epoch).ToShortDateString();
        }
    }
}
