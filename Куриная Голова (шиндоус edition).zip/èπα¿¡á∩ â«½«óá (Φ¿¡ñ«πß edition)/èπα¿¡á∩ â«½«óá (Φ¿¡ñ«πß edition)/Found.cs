﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Куриная_Голова__шиндоус_edition_
{
    public partial class FoundForm : Form
    {
        private const string WritePath = @"found.txt";

        public FoundForm(string wif, string pub)
        {
            InitializeComponent();
            PublicAddress_textBox.Text = pub;
            WIF_textBox.Text = wif;
            WriteFound();
            LoadFound();
        }

        private void LoadFound()
        {
            string received = LoadInfo.GetReceived(PublicAddress_textBox.Text) + " BTC";
            string send = LoadInfo.GetSent(PublicAddress_textBox.Text) + " BTC";
            string balance = LoadInfo.GetBalance(PublicAddress_textBox.Text) + " BTC";
            string firstseen = LoadInfo.GetFirstSeen(PublicAddress_textBox.Text);
            try
            {
                if (received == "-1.0") Received_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else Received_textBox.Text = LoadInfo.GetReceived(PublicAddress_textBox.Text) + " BTC";

                if (send == "-1.0") Send_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else Send_textBox.Text = LoadInfo.GetSent(PublicAddress_textBox.Text) + " BTC";

                if (balance == "-1.0") Balance_textBox.Text = "Время ожидания истекло) (спасибо, blockchain?)";
                else Balance_textBox.Text = LoadInfo.GetBalance(PublicAddress_textBox.Text) + " BTC";

                if (firstseen == "-1") Balance_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else FirstSeen_textBox.Text = LoadInfo.GetFirstSeen(PublicAddress_textBox.Text);
            }
            catch (Exception e1)
            {
                    Log.WriteError("Ошибка брута. " + e1.Message);
            }
        }

        private void WriteFound()
        {
            var file = new FileInfo(WritePath);
            if (!file.Exists)
            {
                var myFile = File.Create(WritePath);
                myFile.Close();
            }

            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("-----------------------------------------------------");
                sw.WriteLine("Public address: " + PublicAddress_textBox.Text);
                sw.WriteLine("Private address: " + WIF_textBox.Text);
            }
        }

        private void Ok_button_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Received_textBox_TextChanged(object sender, EventArgs e)
        {
            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("Total received: " + Received_textBox.Text);
            }
        }

        private void Send_textBox_TextChanged(object sender, EventArgs e)
        {
            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("Total send: " + Send_textBox.Text);
            }
        }

        private void Balance_textBox_TextChanged(object sender, EventArgs e)
        {
            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("Final balance: " + Balance_textBox.Text);
            }
        }

        private void FirstSeen_textBox_TextChanged(object sender, EventArgs e)
        {
            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("First seen: " + FirstSeen_textBox.Text);
            }
        }

        private void FoundForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            using (var sw = new StreamWriter(WritePath, true, Encoding.Default))
            {
                sw.WriteLine("-----------------------------------------------------");
            }
        }
    }
}
