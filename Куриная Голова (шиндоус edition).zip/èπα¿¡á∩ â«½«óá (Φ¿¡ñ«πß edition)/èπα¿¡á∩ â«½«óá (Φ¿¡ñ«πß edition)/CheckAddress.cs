﻿using System;
using System.Windows.Forms;

namespace Куриная_Голова__шиндоус_edition_
{
    public partial class CheckAddressForm : Form
    {
        public CheckAddressForm()
        {
            InitializeComponent();
        }

        private void Check_button_Click(object sender, EventArgs e)
        {
            string received = LoadInfo.GetReceived(PublicAddress_textBox.Text) + " BTC";
            string send = LoadInfo.GetSent(PublicAddress_textBox.Text) + " BTC";
            string balance = LoadInfo.GetBalance(PublicAddress_textBox.Text) + " BTC";
            string firstseen = LoadInfo.GetFirstSeen(PublicAddress_textBox.Text);
            try
            {
                if (received == "-1") Received_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else Received_textBox.Text = LoadInfo.GetReceived(PublicAddress_textBox.Text) + " BTC";

                if (send == "-1") Send_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else Send_textBox.Text = LoadInfo.GetSent(PublicAddress_textBox.Text) + " BTC";

                if (balance == "-1") Balance_textBox.Text = "Время ожидания истекло) (спасибо, blockchain?)";
                else Balance_textBox.Text = LoadInfo.GetBalance(PublicAddress_textBox.Text) + " BTC";

                if (firstseen == "-1") Balance_textBox.Text = "Время ожидания истекло (спасибо, blockchain?)";
                else FirstSeen_textBox.Text = LoadInfo.GetFirstSeen(PublicAddress_textBox.Text);

                if (firstseen == "01.01.1970") Seen_label.Visible = true;
                else Seen_label.Visible = false;
            }
            catch (Exception ex)
            {
                Log.WriteError("Ошибка чекера. " + ex.Message);
            }
        }

        private static string Epoch2String(int epoch)
        {
            return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(epoch).ToShortDateString();
        }
    }
}
