﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Sha256Manager
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using Cryptography.ECDSA.Internal.Sha256;

namespace Cryptography.ECDSA
{
  public class Sha256Manager
  {
    private readonly Sha256T _sha;

    public Sha256Manager()
    {
      this._sha = new Sha256T();
      Hash.Initialize(this._sha);
    }

    public void Write(byte[] data)
    {
      Hash.Write(this._sha, data, (uint) data.Length);
    }

    public void Write(byte[] data, int len)
    {
      Hash.Write(this._sha, data, (uint) len);
    }

    public byte[] FinalizeAndGetResult()
    {
      var out32 = new byte[32];
      Hash.Finalize(this._sha, out32);
      return out32;
    }

    public static byte[] GetHash(byte[] data)
    {
      var hash = new Sha256T();
      Hash.Initialize(hash);
      Hash.Write(hash, data, (uint) data.Length);
      var out32 = new byte[32];
      Hash.Finalize(hash, out32);
      return out32;
    }
  }
}
