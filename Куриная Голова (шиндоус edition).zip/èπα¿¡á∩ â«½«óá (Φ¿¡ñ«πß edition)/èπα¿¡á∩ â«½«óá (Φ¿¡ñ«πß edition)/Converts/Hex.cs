﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Hex
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

using System;
using System.Collections.Generic;
using System.Linq;

namespace Cryptography.ECDSA
{
  public static class Hex
  {
    public static int HexToInteger(byte[] hex)
    {
      var num = 0;
      for (var index = 0; index < hex.Length; ++index)
        num = num << 8 | (int) hex[index];
      return num;
    }

    public static byte[] HexToBytes(string hex)
    {
      if (hex.Length % 2 != 0)
        hex = "0" + hex;
      var numArray = new byte[hex.Length >> 1];
      for (var index = 0; index < numArray.Length; ++index)
        numArray[index] = (byte) ((Hex.GetHexVal(hex[index << 1]) << 4) + Hex.GetHexVal(hex[(index << 1) + 1]));
      return numArray;
    }

    private static int GetHexVal(char hex)
    {
      var num = (int) hex;
      return num - (num < 58 ? 48 : (num < 97 ? 55 : 87));
    }

    public static byte[] Join(params byte[][] values)
    {
      var numArray1 = new byte[((IEnumerable<byte[]>) values).Sum<byte[]>((Func<byte[], int>) (i => i.Length))];
      var destinationIndex = 0;
      for (var index = 0; index < values.Length; ++index)
      {
        var numArray2 = values[index];
        if (numArray2.Length != 0)
        {
          Array.Copy((Array) numArray2, 0, (Array) numArray1, destinationIndex, numArray2.Length);
          destinationIndex += numArray2.Length;
        }
      }
      return numArray1;
    }

    public static string ToString(byte[] hex)
    {
      return string.Join(string.Empty, ((IEnumerable<byte>) hex).Select<byte, string>((Func<byte, string>) (i => i.ToString("x2"))));
    }
  }
}
