﻿using System;
using System.Windows.Forms;

namespace Куриная_Голова__шиндоус_edition_
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void AboutForm_Load(object sender, EventArgs e)
        {
        }
    }
}
