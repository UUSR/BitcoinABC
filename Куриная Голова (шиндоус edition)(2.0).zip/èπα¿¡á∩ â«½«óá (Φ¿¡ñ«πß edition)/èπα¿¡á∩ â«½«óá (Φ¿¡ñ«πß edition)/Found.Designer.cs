﻿namespace Куриная_Голова__шиндоус_edition_
{
    partial class FoundForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FoundForm));
            this.label5 = new System.Windows.Forms.Label();
            this.Send_textBox = new System.Windows.Forms.TextBox();
            this.FirstSeen_textBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Balance_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Received_textBox = new System.Windows.Forms.TextBox();
            this.PublicAddress_textBox = new System.Windows.Forms.TextBox();
            this.Ok_button = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.WIF_textBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 93);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Total send:";
            // 
            // Send_textBox
            // 
            this.Send_textBox.Location = new System.Drawing.Point(133, 90);
            this.Send_textBox.Name = "Send_textBox";
            this.Send_textBox.ReadOnly = true;
            this.Send_textBox.Size = new System.Drawing.Size(360, 20);
            this.Send_textBox.TabIndex = 19;
            this.Send_textBox.TextChanged += new System.EventHandler(this.Send_textBox_TextChanged);
            // 
            // FirstSeen_textBox
            // 
            this.FirstSeen_textBox.Location = new System.Drawing.Point(133, 142);
            this.FirstSeen_textBox.Name = "FirstSeen_textBox";
            this.FirstSeen_textBox.ReadOnly = true;
            this.FirstSeen_textBox.Size = new System.Drawing.Size(360, 20);
            this.FirstSeen_textBox.TabIndex = 18;
            this.FirstSeen_textBox.TextChanged += new System.EventHandler(this.FirstSeen_textBox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "First seen:";
            // 
            // Balance_textBox
            // 
            this.Balance_textBox.Location = new System.Drawing.Point(133, 116);
            this.Balance_textBox.Name = "Balance_textBox";
            this.Balance_textBox.ReadOnly = true;
            this.Balance_textBox.Size = new System.Drawing.Size(360, 20);
            this.Balance_textBox.TabIndex = 16;
            this.Balance_textBox.TextChanged += new System.EventHandler(this.Balance_textBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Final balance: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 67);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Total received:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Public bitcoin address: ";
            // 
            // Received_textBox
            // 
            this.Received_textBox.Location = new System.Drawing.Point(133, 64);
            this.Received_textBox.Name = "Received_textBox";
            this.Received_textBox.ReadOnly = true;
            this.Received_textBox.Size = new System.Drawing.Size(360, 20);
            this.Received_textBox.TabIndex = 12;
            this.Received_textBox.TextChanged += new System.EventHandler(this.Received_textBox_TextChanged);
            // 
            // PublicAddress_textBox
            // 
            this.PublicAddress_textBox.Location = new System.Drawing.Point(133, 12);
            this.PublicAddress_textBox.Name = "PublicAddress_textBox";
            this.PublicAddress_textBox.ReadOnly = true;
            this.PublicAddress_textBox.Size = new System.Drawing.Size(360, 20);
            this.PublicAddress_textBox.TabIndex = 11;
            // 
            // Ok_button
            // 
            this.Ok_button.Location = new System.Drawing.Point(12, 201);
            this.Ok_button.Name = "Ok_button";
            this.Ok_button.Size = new System.Drawing.Size(481, 23);
            this.Ok_button.TabIndex = 21;
            this.Ok_button.Text = "Принял, на созвоне!";
            this.Ok_button.UseVisualStyleBackColor = true;
            this.Ok_button.Click += new System.EventHandler(this.Ok_button_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Private address (WIF):";
            // 
            // WIF_textBox
            // 
            this.WIF_textBox.Location = new System.Drawing.Point(133, 38);
            this.WIF_textBox.Name = "WIF_textBox";
            this.WIF_textBox.ReadOnly = true;
            this.WIF_textBox.Size = new System.Drawing.Size(360, 20);
            this.WIF_textBox.TabIndex = 23;
            // 
            // FoundForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 236);
            this.Controls.Add(this.WIF_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Ok_button);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Send_textBox);
            this.Controls.Add(this.FirstSeen_textBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Balance_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Received_textBox);
            this.Controls.Add(this.PublicAddress_textBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FoundForm";
            this.Text = "...И У НАС ПОБЕДИТЕЛЬ!";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FoundForm_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Send_textBox;
        private System.Windows.Forms.TextBox FirstSeen_textBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Balance_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Received_textBox;
        private System.Windows.Forms.TextBox PublicAddress_textBox;
        private System.Windows.Forms.Button Ok_button;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox WIF_textBox;
    }
}