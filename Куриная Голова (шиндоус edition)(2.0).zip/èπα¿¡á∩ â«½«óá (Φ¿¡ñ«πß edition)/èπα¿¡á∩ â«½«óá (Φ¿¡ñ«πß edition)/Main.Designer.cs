﻿namespace Куриная_Голова__шиндоус_edition_
{
    partial class Main
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.проверкаАдресаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.коневертерToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dEBUGRandomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.наблюдательexeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Status_groupBox = new System.Windows.Forms.GroupBox();
            this.StartStop_button = new System.Windows.Forms.Button();
            this.Time_label = new System.Windows.Forms.Label();
            this.Wallets_label = new System.Windows.Forms.Label();
            this.Keys_label = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Settings_groupBox = new System.Windows.Forms.GroupBox();
            this.Empty_checkBox = new System.Windows.Forms.CheckBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.Status_groupBox.SuspendLayout();
            this.Settings_groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.проверкаАдресаToolStripMenuItem,
            this.коневертерToolStripMenuItem,
            this.dEBUGRandomToolStripMenuItem,
            this.наблюдательexeToolStripMenuItem,
            this.оПрограммеToolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(808, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // проверкаАдресаToolStripMenuItem
            // 
            this.проверкаАдресаToolStripMenuItem.Name = "проверкаАдресаToolStripMenuItem";
            this.проверкаАдресаToolStripMenuItem.Size = new System.Drawing.Size(113, 20);
            this.проверкаАдресаToolStripMenuItem.Text = "Проверка адреса";
            this.проверкаАдресаToolStripMenuItem.Click += new System.EventHandler(this.проверкаАдресаToolStripMenuItem_Click);
            // 
            // коневертерToolStripMenuItem
            // 
            this.коневертерToolStripMenuItem.Name = "коневертерToolStripMenuItem";
            this.коневертерToolStripMenuItem.Size = new System.Drawing.Size(124, 20);
            this.коневертерToolStripMenuItem.Text = "Конвертер адресов";
            this.коневертерToolStripMenuItem.Click += new System.EventHandler(this.коневертерToolStripMenuItem_Click);
            // 
            // dEBUGRandomToolStripMenuItem
            // 
            this.dEBUGRandomToolStripMenuItem.Name = "dEBUGRandomToolStripMenuItem";
            this.dEBUGRandomToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.dEBUGRandomToolStripMenuItem.Text = "Наглядный рандом";
            this.dEBUGRandomToolStripMenuItem.Click += new System.EventHandler(this.dEBUGRandomToolStripMenuItem_Click);
            // 
            // наблюдательexeToolStripMenuItem
            // 
            this.наблюдательexeToolStripMenuItem.Name = "наблюдательexeToolStripMenuItem";
            this.наблюдательexeToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.наблюдательexeToolStripMenuItem.Text = "Наблюдатель";
            this.наблюдательexeToolStripMenuItem.Click += new System.EventHandler(this.наблюдательexeToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem2
            // 
            this.оПрограммеToolStripMenuItem2.Name = "оПрограммеToolStripMenuItem2";
            this.оПрограммеToolStripMenuItem2.Size = new System.Drawing.Size(103, 20);
            this.оПрограммеToolStripMenuItem2.Text = "О программе...";
            this.оПрограммеToolStripMenuItem2.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem2_Click);
            // 
            // Status_groupBox
            // 
            this.Status_groupBox.Controls.Add(this.StartStop_button);
            this.Status_groupBox.Controls.Add(this.Time_label);
            this.Status_groupBox.Controls.Add(this.Wallets_label);
            this.Status_groupBox.Controls.Add(this.Keys_label);
            this.Status_groupBox.Controls.Add(this.label3);
            this.Status_groupBox.Controls.Add(this.label2);
            this.Status_groupBox.Controls.Add(this.label1);
            this.Status_groupBox.Location = new System.Drawing.Point(253, 27);
            this.Status_groupBox.Name = "Status_groupBox";
            this.Status_groupBox.Size = new System.Drawing.Size(344, 117);
            this.Status_groupBox.TabIndex = 12;
            this.Status_groupBox.TabStop = false;
            this.Status_groupBox.Text = "Статистика: ";
            // 
            // StartStop_button
            // 
            this.StartStop_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StartStop_button.Location = new System.Drawing.Point(6, 88);
            this.StartStop_button.Name = "StartStop_button";
            this.StartStop_button.Size = new System.Drawing.Size(332, 23);
            this.StartStop_button.TabIndex = 6;
            this.StartStop_button.Text = "ГОЛОВА, ДАЙ ДЕНЕГ!";
            this.StartStop_button.UseVisualStyleBackColor = true;
            this.StartStop_button.Click += new System.EventHandler(this.StartStop_button_Click);
            // 
            // Time_label
            // 
            this.Time_label.AutoSize = true;
            this.Time_label.Location = new System.Drawing.Point(129, 64);
            this.Time_label.Name = "Time_label";
            this.Time_label.Size = new System.Drawing.Size(49, 13);
            this.Time_label.TabIndex = 5;
            this.Time_label.Text = "00:00:00";
            // 
            // Wallets_label
            // 
            this.Wallets_label.AutoSize = true;
            this.Wallets_label.Location = new System.Drawing.Point(129, 42);
            this.Wallets_label.Name = "Wallets_label";
            this.Wallets_label.Size = new System.Drawing.Size(13, 13);
            this.Wallets_label.TabIndex = 4;
            this.Wallets_label.Text = "0";
            // 
            // Keys_label
            // 
            this.Keys_label.AutoSize = true;
            this.Keys_label.Location = new System.Drawing.Point(129, 20);
            this.Keys_label.Name = "Keys_label";
            this.Keys_label.Size = new System.Drawing.Size(13, 13);
            this.Keys_label.TabIndex = 3;
            this.Keys_label.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Прошло времени: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Найдено кошельков: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Проверено ключей:";
            // 
            // Settings_groupBox
            // 
            this.Settings_groupBox.Controls.Add(this.Empty_checkBox);
            this.Settings_groupBox.Location = new System.Drawing.Point(253, 159);
            this.Settings_groupBox.Name = "Settings_groupBox";
            this.Settings_groupBox.Size = new System.Drawing.Size(344, 40);
            this.Settings_groupBox.TabIndex = 13;
            this.Settings_groupBox.TabStop = false;
            this.Settings_groupBox.Text = "Настройки";
            // 
            // Empty_checkBox
            // 
            this.Empty_checkBox.AutoSize = true;
            this.Empty_checkBox.Checked = true;
            this.Empty_checkBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.Empty_checkBox.Location = new System.Drawing.Point(6, 19);
            this.Empty_checkBox.Name = "Empty_checkBox";
            this.Empty_checkBox.Size = new System.Drawing.Size(156, 17);
            this.Empty_checkBox.TabIndex = 0;
            this.Empty_checkBox.Text = "Выдавать пустые кошели";
            this.Empty_checkBox.UseVisualStyleBackColor = true;
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Куриная_Голова__шиндоус_edition_.Properties.Resources._15431415190330;
            this.pictureBox4.Location = new System.Drawing.Point(253, 215);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(543, 198);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 17;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Куриная_Голова__шиндоус_edition_.Properties.Resources._15428894681820;
            this.pictureBox3.Location = new System.Drawing.Point(12, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(235, 386);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 16;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Куриная_Голова__шиндоус_edition_.Properties.Resources._15411568963620;
            this.pictureBox1.Location = new System.Drawing.Point(603, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(193, 182);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 14;
            this.pictureBox1.TabStop = false;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 425);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Settings_groupBox);
            this.Controls.Add(this.Status_groupBox);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Храм головы.exe";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Main_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.Status_groupBox.ResumeLayout(false);
            this.Status_groupBox.PerformLayout();
            this.Settings_groupBox.ResumeLayout(false);
            this.Settings_groupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem коневертерToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem проверкаАдресаToolStripMenuItem;
        private System.Windows.Forms.GroupBox Status_groupBox;
        private System.Windows.Forms.GroupBox Settings_groupBox;
        private System.Windows.Forms.CheckBox Empty_checkBox;
        private System.Windows.Forms.Button StartStop_button;
        private System.Windows.Forms.Label Time_label;
        private System.Windows.Forms.Label Wallets_label;
        private System.Windows.Forms.Label Keys_label;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem dEBUGRandomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem наблюдательexeToolStripMenuItem;
    }
}

