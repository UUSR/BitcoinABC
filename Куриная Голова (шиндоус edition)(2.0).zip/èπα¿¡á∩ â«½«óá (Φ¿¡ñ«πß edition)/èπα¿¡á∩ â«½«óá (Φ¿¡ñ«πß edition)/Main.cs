﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace Куриная_Голова__шиндоус_edition_
{
    public partial class Main : Form
    {
        private Thread _bruteThread;
        private bool _started = false;
        private int _keys = 0;
        private int _wallets = 0;

        private int _hours = 0;
        private int _minutes = 0;
        private int _seconds = 0;
        private string _h = "00";
        private string _m = "00";
        private string _s = "00";

        public Main()
        {
            try
            {
                Log.NewSession();
                InitializeComponent();
                var emptyToolTip = new ToolTip {AutoPopDelay = 15000};
                emptyToolTip.SetToolTip(Empty_checkBox, "Выдавать (и считать) кошельки с нулевым балансом. ");
            }
            catch (Exception e)
            {
                Log.WriteError(e.Message);
                MessageBox.Show(("Ошибка инициализации. \n" + e.Message), "Ошибка", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                Application.Exit();
            }
        }

        private void коневертерToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var convertForm = new ConvertForm();
                convertForm.Show();
            }
            catch (Exception e2)
            {
                Log.WriteError("Ошибка инициализации конвертера. " + e2.Message);
                MessageBox.Show(("Ошибка инициализации конвертера. \n" + e2.Message), "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void проверкаАдресаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                var check = new CheckAddressForm();
                check.Show();
            }
            catch (Exception e3)
            {
                Log.WriteError("Ошибка инициализации проверки адреса. " + e3.Message);
                MessageBox.Show(("Ошибка инициализации проверки адреса. \n" + e3.Message), "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void StartStop_button_Click(object sender, EventArgs e)
        {
            try
            {
                if (!_started)
                {
                    Settings_groupBox.Enabled = false;
                    timer.Enabled = true;
                    _bruteThread = new Thread(Bruteforce);
                    _bruteThread.Start();
                    _started = true;
                    StartStop_button.Text = "Остановить";
                    return;
                }

                if (_started)
                {
                    Settings_groupBox.Enabled = true;
                    timer.Enabled = false;
                    _started = false;
                    StartStop_button.Text = "ГОЛОВА, ДАЙ ДЕНЕГ!";
                }
            }
            catch (Exception e1)
            {
                Log.WriteError("Ошибка старт-кнопки. " + e1.Message);
            }
        }

        private void Bruteforce()
        {
            while (true)
            {
                try
                {
                    if (_started == false) break;
                    var comp = KeyPair.Generate(true);
                    var uncomp = KeyPair.Generate(false);

                    var compBalance = comp.GetBalance();
                    var uncompBalance = uncomp.GetBalance();

                    var compTimestamp = comp.GetSeen();
                    var uncompTimestamp = uncomp.GetSeen();

                    //compressed
                    if (Empty_checkBox.Checked && compTimestamp != 0)
                    {
                        Found_init(comp.Private, comp.Public);
                    }

                    if (!Empty_checkBox.Checked && compTimestamp != 0 && compBalance > 0)
                    {
                        Found_init(comp.Private, comp.Public);
                    }

                    //uncompressed
                    if (Empty_checkBox.Checked && uncompTimestamp != 0)
                    {
                        Found_init(uncomp.Private, uncomp.Public);
                    }

                    if (!Empty_checkBox.Checked && uncompTimestamp != 0 && uncompBalance > 0)
                    {
                        Found_init(uncomp.Private, uncomp.Public);
                    }

                    _keys++;
                    BeginInvoke((MethodInvoker) delegate { Keys_label.Text = _keys.ToString(); });
                }
                catch (Exception e) // WebException
                {
                    Log.WriteError("Ошибка брута. " + e.Message);
                }
            }
        }

        private void Found_init(string priv, string pub)
        {
            _wallets++;
            BeginInvoke((MethodInvoker) delegate { Wallets_label.Text = _wallets.ToString(); });
            var found = new FoundForm(priv, pub);
            found.Show();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            _seconds++;
            if (_seconds > 59)
            {
                _seconds = 0;
                _minutes++;
                if (_minutes > 59)
                {
                    _minutes = 0;
                    _hours++;
                }
            }

            if (_seconds < 10) _s = "0" + _seconds;
            else _s = _seconds.ToString();
            if (_minutes < 10) _m = "0" + _minutes;
            else _m = _minutes.ToString();
            if (_hours < 10) _h = "0" + _hours;
            else _h = _hours.ToString();
            Time_label.Text = _h + ":" + _m + ":" + _s;
        }

        private void оПрограммеToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            var about = new AboutForm();
            about.Show();
        }

        private void dEBUGRandomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var randomForm = new RandomForm();
            randomForm.Show();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            Log.SessionEnd();
        }

        private void наблюдательexeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Если ты это читаешь - значит я уже начал пилить это. \n >Кого пилить? \n Наблюдатель за желтыми(пустыми) кошельками. Можете начинать заготавливать wallet.txt (паблик кей через строчку).",
                "Еще не готово", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
