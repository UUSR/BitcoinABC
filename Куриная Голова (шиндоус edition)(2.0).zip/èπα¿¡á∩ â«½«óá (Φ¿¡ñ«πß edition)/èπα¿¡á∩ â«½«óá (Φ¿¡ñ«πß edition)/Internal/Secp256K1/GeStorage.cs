﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.GeStorage
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal class GeStorage
  {
    public FeStorage X;
    public FeStorage Y;

    public GeStorage()
    {
      this.X = new FeStorage();
      this.Y = new FeStorage();
    }
  }
}
