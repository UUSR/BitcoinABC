﻿// Decompiled with JetBrains decompiler
// Type: Cryptography.ECDSA.Internal.Secp256K1.GeJ
// Assembly: PenisWallet, Version=1.0.6902.39186, Culture=neutral, PublicKeyToken=null
// MVID: 5D512FED-2A00-45E0-BCC4-D3FF215B3DE6
// Assembly location: E:\temp2\PenisWallet.exe

namespace Cryptography.ECDSA.Internal.Secp256K1
{
  internal class GeJ
  {
    public Fe X;
    public Fe Y;
    public Fe Z;
    public bool Infinity;

    public GeJ()
    {
      this.X = new Fe();
      this.Y = new Fe();
      this.Z = new Fe();
    }

    public GeJ(Fe xVal, Fe yVal, Fe zVal)
    {
      this.X = xVal ?? new Fe();
      this.Y = yVal ?? new Fe();
      this.Z = zVal ?? new Fe();
    }

    public GeJ Clone()
    {
      var x = this.X;
      var xVal = x != null ? x.Clone() : (Fe) null;
      var y = this.Y;
      var yVal = y != null ? y.Clone() : (Fe) null;
      var z = this.Z;
      var zVal = z != null ? z.Clone() : (Fe) null;
      return new GeJ(xVal, yVal, zVal);
    }
  }
}
